#ifndef GAME_H
#define GAME_H

#include "screen.h"

#include "globals.h"

class Game {
private:
    ScreenType screen_type = ScreenType::kMenu;
    bool closed = false;

public:
    Game();
    
    // Game screen
    ScreenType GetScreenType();
    void ScreenToMenu();
    void ScreenToGameSelection();
    void ScreenToGameplay();
    void ScreenToContinue();
    void ScreenToSettings();

    void CloseWindow();
    bool WindowClosed();
    
    void InitGame();
    void RenderGame();
    // 

};

#endif // GAME_H