#include "game.h"


#include "raylib.h"
#define RAYGUI_IMPLEMENTATION
#include "raygui.h"

ScreenType Game::GetScreenType() {
    return screen_type;
}

void Game::InitGame() {
    InitWindow(global::kScreenWidth, global::kScreenHeight, "CS161 - Minesweeper");
    SetTargetFPS(global::kFramesPerSecond);
}

void Game::CloseWindow() {
    closed = true;
}

bool Game::WindowClosed() {
    if(WindowShouldClose()) {
        CloseWindow();
        return 1;
    }
    return 0;
    //return WindowShouldClose();
    //return closed;
}

void Game::RenderGame() {
    BeginDrawing();
    bool new_game_selected = GuiButton({100, 100, 100, 100},
                                        "New game");

    if(WindowClosed()) CloseWindow();

    EndDrawing();
}

Game::Game() {}

/*
class Game {
public:
    ScreenType GetScreenType() {
        return screen_type;
    }
    
    void CloseWindow() {
        closed = true;
    }

    bool WindowClosed() {
        return closed;
    }

    void InitGame() {
        InitWindow(global::kScreenWidth, global::kScreenHeight, "CS161 - Minesweeper");
        SetTargetFPS(global::kFramesPerSecond);
    }

    void RenderGame() {
        /*switch(global::GetScreenType()) {
            case ScreenType::kMenu:
                menu_screen::interact();
            break;
            case ScreenType::kGameSelection:

            break;
            case ScreenType::kGameplay:

            break;
            case ScreenType::kSettings:

            break;
            default:
                break;
        }

        BeginDrawing();
        /*{
            switch(global::GetScreenType()) {
                case ScreenType::kMenu:
                    menu_screen::paint();
                break;
                case ScreenType::kGameSelection:

                break;
                case ScreenType::kGameplay:

                break;
                case ScreenType::kSettings:

                break;
                default:
                    break;
            }
        }

        EndDrawing();

        if(WindowClosed()) CloseWindow();
    }

    Game() {}
};*/