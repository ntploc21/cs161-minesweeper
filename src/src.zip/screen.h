#ifndef SCREEN_H
#define SCREEN_H

enum class ScreenType {
    kMenu,
    kGameSelection,
    kGameplay,
    kSettings
};

#endif // SCREEN_H